
#include <iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter a number:";
    cin>>a;
    cout<<"\nMultiplication table of"<<a<<"is:";
    for(int i=1;i<11;i++)
    {
        cout<<"\n"<<a*i;
    }
    return 0;
}
