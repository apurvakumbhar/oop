

#include <iostream>
using namespace std;
int main()
{
    int a, b,c;
    
    
    cout<<"Enter three numbers:";
    cin>>a>>b>>c;
    
    cout<<"\nAddition of these two numbers:";
    cout<<a+b;
    
    cout<<"\nSubstraction of these two numbers:";
    cout<<a-b;
    
    cout<<"\nMultiplication of these two numbers";
    cout<<a*b;
    
    cout<<"\nDevision of these two numbers:";
    cout<<(float) a/b;
    
    cout<<"\nModulus is:";
    cout<<a%b;
    
    return 0;
}
