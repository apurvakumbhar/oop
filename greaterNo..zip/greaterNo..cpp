
#include <iostream>
using namespace std;
int main()
{
    int a, b,c;
    
    
    cout<<"Enter three numbers:";
    cin>>a>>b>>c;
    
    if(a>b && a>c)
    {
        cout<<a<<"is greater.";
    }
    
     if(b>a && b>c)
    {
        cout<<b<<"is greater.";
    }
    
     if(c>a && c>b)
    {
        cout<<c<<"is greater.";
    }
    
    if(a==b && b==c)
    {
        cout<<"All having same values.";
    }
    
    if(a==b && a>c)
    {
        cout<<a<<" is greater";
    }
    
    if(b==c && b>a)
    {
        cout<<b<<" is greater.";
    }
    
    if(a==c && a>b)
    {
        cout<<a<<" is greater.";
    }
    return 0;
}
